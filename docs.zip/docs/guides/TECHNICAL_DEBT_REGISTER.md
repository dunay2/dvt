# Technical Debt Register (Iterative)

> Document control
>
> - Version: `v1.3.0`
> - Status: `active`
> - Last updated (UTC): `2026-02-20`
> - Owner: `Engineering / AI Delivery Governance`
> - Mandatory cadence: **every iteration**

## Purpose

Maintain a living, auditable, and prioritized technical debt register to reduce operational risk, improve maintainability, and prevent important debt from being excluded from the delivery cycle.

## Mandatory rule per iteration

In **every iteration** (issue/PR change or implementation cycle), the team MUST:

1. Review the current register state.
2. Update entries impacted by the iteration changes.
3. Record newly identified debt (if any).
4. Explicitly record `no new debt` when no new entries are identified.

## Iteration update workflow

### 1) Iteration start

- Review the active debt table.
- Confirm which entries remain open and their priority.
- Check whether any debt is blocking the current scope.

### 2) During implementation

- If new debt appears, create an entry immediately with `id`, `risk`, `plan`, and `owner`.
- If an existing debt item changes in scope/risk, update it immediately.

### 3) Iteration close

- Update `status`, `last review (UTC)`, and `evidence` (issue/PR/file).
- Move resolved entries to `closed` (do not delete history).
- Add one row to the iteration history.

## Register conventions

- `id`: `TD-0001`, `TD-0002`, ...
- `type`: `code | test | docs | infra | process`
- `risk`: `Low | Medium | High`
- `effort`: `Low | Medium | High`
- `status`: `open | planned | in-progress | blocked | closed`

## New entry template

| id      | title | type | area | detected_at_utc | risk | effort | status | owner | mitigation plan | objective | evidence | last review (UTC) |
| ------- | ----- | ---- | ---- | --------------- | ---- | ------ | ------ | ----- | --------------- | --------- | -------- | ----------------- |
| TD-XXXX |       |      |      |                 |      |        | open   |       |                 |           |          |                   |

## Active technical debt register

| id      | title                                                                                                    | type    | area                                              | detected_at_utc | risk   | effort | status  | owner                                 | mitigation plan                                                                                                                                                                                      | objective                                                                | evidence                                                                                                                                                                                                                                                        | last review (UTC) |
| ------- | -------------------------------------------------------------------------------------------------------- | ------- | ------------------------------------------------- | --------------- | ------ | ------ | ------- | ------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------- |
| TD-0001 | Formalize mandatory iterative debt-register updates in core process docs                                 | process | docs/guides                                       | 2026-02-17      | Medium | Low    | closed  | Engineering / AI Governance           | Integrate the register into process documents and the documentation index.                                                                                                                           | Standardize governance                                                   | `docs/guides/AI_ISSUE_RESOLUTION_PLAYBOOK.md`, `docs/INDEX.md`                                                                                                                                                                                                  | 2026-02-17        |
| TD-0002 | Engine public API still exports Temporal/Conductor stub adapters                                         | code    | packages/@dvt/engine/src                          | 2026-02-17      | High   | Medium | open    | Engine maintainers                    | Remove stub exports from the public entrypoint (or move to explicit test-only exports); keep only production-capable adapters in default API.                                                        | Prevent accidental runtime use of non-functional adapters                | `packages/@dvt/engine/src/index.ts`, `packages/@dvt/engine/src/adapters/temporal/TemporalAdapterStub.ts`, `packages/@dvt/engine/src/adapters/conductor/ConductorAdapterStub.ts`, `docs/planning/ISSUE_5_TEMPORAL_ADAPTER_STATUS_AND_IMPLEMENTATION_PROPOSAL.md` | 2026-02-17        |
| TD-0003 | Retry signal flow (`RETRY_STEP` / `RETRY_RUN`) remains NotImplemented across engine and Temporal adapter | code    | packages/engine + packages/@dvt/adapter-temporal  | 2026-02-17      | Medium | High   | planned | Engine + Temporal adapter maintainers | Implement deterministic retry semantics end-to-end (engine mapping, adapter handling, tests, and contract alignment).                                                                                | Close Phase-2 functional gap in control signals                          | `packages/@dvt/engine/src/core/WorkflowEngine.ts`, `packages/@dvt/adapter-temporal/src/TemporalAdapter.ts`, `docs/architecture/engine/adapters/temporal/EnginePolicies.md`                                                                                      | 2026-02-17        |
| TD-0004 | Legacy adapter package still active in workspace and contains unresolved TODO-based test setup           | test    | packages/adapters-legacy                          | 2026-02-17      | Medium | Medium | open    | Platform maintainers                  | Decide legacy end-state (archive/remove/migrate), then move any remaining useful tests to active packages and close TODOs.                                                                           | Reduce confusion and split-brain test maintenance                        | `packages/adapters-legacy/README.md`, `packages/adapters-legacy/test/setup.ts`                                                                                                                                                                                  | 2026-02-17        |
| TD-0005 | Empty root `test/` placeholder still exists despite cleanup recommendation                               | repo    | root                                              | 2026-02-17      | Low    | Low    | open    | Repo maintainers                      | Remove empty root placeholder and verify CI/scripts/docs no longer reference it.                                                                                                                     | Complete monorepo structure cleanup                                      | `docs/REPO_STRUCTURE_SUMMARY.md`, root `test/` directory (empty)                                                                                                                                                                                                | 2026-02-17        |
| TD-0006 | DAG dependency field (`dependsOn`) initially implemented only in adapter-local plan typing               | code    | packages/@dvt/adapter-temporal + shared contracts | 2026-02-17      | Medium | Medium | closed  | Contracts + Temporal maintainers      | Promote `dependsOn` to canonical shared plan contract and propagate validation/docs across engine and adapters.                                                                                      | Avoid contract drift between workflow interpreter and shared plan schema | `packages/@dvt/adapter-temporal/src/engine-types.ts`, `packages/@dvt/adapter-temporal/src/workflows/RunPlanWorkflow.ts`, `packages/@dvt/engine/src/contracts/executionPlan.ts`, `packages/@dvt/engine/src/adapters/mock/MockAdapter.ts`                         | 2026-02-17        |
| TD-0007 | Lint debt backlog remains open in legacy and adapter side-paths                                          | process | packages/adapters-legacy + adapter-postgres       | 2026-02-17      | Medium | Medium | open    | Platform maintainers                  | Resolve by explicit route batches and closure criteria (`eslint --max-warnings 0` per target scope), or archive legacy scope with owner sign-off.                                                    | Replace vague lint-debt tracking with auditable execution batches        | `docs/status/IMPLEMENTATION_SUMMARY.md`, `packages/adapters-legacy/**`, `packages/@dvt/adapter-postgres/**`, `packages/@dvt/engine/legacy-top-level-engine/**`                                                                                                  | 2026-02-17        |
| TD-0008 | Documentation/path normalization tracked as generic note without concrete file list                      | docs    | docs/\*                                           | 2026-02-17      | Low    | Medium | open    | Documentation maintainers             | Maintain explicit normalization queue by file path and update status each iteration until closed.                                                                                                    | Ensure documentation debt is actionable and verifiable                   | `docs/status/IMPLEMENTATION_SUMMARY.md`, `docs/REPO_STRUCTURE_SUMMARY.md`, `docs/planning/ISSUE_5_TEMPORAL_ADAPTER_STATUS_AND_IMPLEMENTATION_PROPOSAL.md`, `docs/knowledge/ROADMAP_AND_ISSUES_MAP.md`, `docs/INDEX.md`                                          | 2026-02-17        |
| TD-0009 | Temporal workflow determinism linting guardrails are not yet enforced in CI for adapter workflows        | process | packages/@dvt/adapter-temporal + CI               | 2026-02-18      | Medium | Low    | planned | Temporal adapter maintainers          | Add deterministic-workflow lint rules/checks in CI and pre-push path for Temporal workflow files; fail build on violations.                                                                          | Prevent non-deterministic APIs from entering workflow sandbox code       | `packages/@dvt/adapter-temporal/src/workflows/RunPlanWorkflow.ts`, `docs/decisions/ADR-0007-temporal-retry-policy-mvp.md`, `docs/status/IMPLEMENTATION_SUMMARY.md`                                                                                              | 2026-02-18        |
| TD-0010 | Activity heartbeat/timeout strategy for long-running steps is not formalized in adapter runtime          | code    | packages/@dvt/adapter-temporal                    | 2026-02-18      | Medium | Medium | planned | Temporal adapter maintainers          | Define and implement default `startToClose`/`scheduleToClose` + heartbeat policy for long-running step execution paths.                                                                              | Avoid silent hangs and improve failure detectability for long activities | `packages/@dvt/adapter-temporal/src/workflows/RunPlanWorkflow.ts`, `packages/@dvt/adapter-temporal/src/activities/stepActivities.ts`, `docs/decisions/ADR-0007-temporal-retry-policy-mvp.md`                                                                    | 2026-02-18        |
| TD-0011 | Engine internals still contain non-typed `throw new Error(...)` branches                                 | code    | packages/@dvt/engine/src/core                     | 2026-02-20      | Medium | Low    | open    | Engine maintainers                    | Replace internal generic throws with domain typed errors where stable error code semantics are required; keep behavior unchanged.                                                                    | Complete typed-error consistency across engine paths                     | `packages/@dvt/engine/src/core/WorkflowEngine.ts`, `docs/planning/IMPLEMENTATION-PLAN-ARCH-REVIEW.md`, `ROADMAP.md`                                                                                                                                             | 2026-02-20        |
| TD-0012 | `src`/`dist` artifact divergence risk after hardening changes                                            | process | packages/adapter-postgres + packages/engine       | 2026-02-20      | High   | Low    | open    | Package maintainers                   | Keep `dist` out of microcommits while ignored by repository policy; close debt only via explicit release/rebuild workflow that regenerates artifacts from `src` and validates parity before publish. | Prevent shipping stale runtime behavior from generated artifacts         | `packages/@dvt/adapter-postgres/src/PostgresStateStoreAdapter.ts`, `packages/@dvt/adapter-postgres/dist/PostgresStateStoreAdapter.js`, `.gitignore`, `docs/planning/IMPLEMENTATION-PLAN-ARCH-REVIEW.md`                                                         | 2026-02-20        |
| TD-0013 | Test fixtures still use permissive `as any` in engine tests                                              | test    | packages/@dvt/engine/test                         | 2026-02-20      | Medium | Medium | open    | Engine test maintainers               | Tighten fixture typing incrementally (factory helpers + explicit interface types) in small PR slices to improve drift detection.                                                                     | Reduce false negatives and strengthen compile-time contract checks       | `packages/@dvt/engine/test/core/WorkflowEngine.test.ts`, `packages/@dvt/engine/test/security/authorizer.deny.test.ts`, `docs/planning/IMPLEMENTATION-PLAN-ARCH-REVIEW.md`                                                                                       | 2026-02-20        |

## Iteration history

- 2026-02-17 · bootstrap
  - Summary: Created the technical debt register and defined mandatory iterative update flow.
  - Evidence: `docs/guides/TECHNICAL_DEBT_REGISTER.md`, `docs/INDEX.md`
- 2026-02-17 · iteration-1
  - Summary: Integrated register governance into the playbook; updated TD-0001 and recorded no additional debt.
  - Evidence: `docs/guides/AI_ISSUE_RESOLUTION_PLAYBOOK.md`
- 2026-02-17 · iteration-2
  - Summary: Repository audit completed; added TD-0002..TD-0005 for stub exports, retry gap, legacy adapter area, and root placeholder cleanup.
  - Evidence: `packages/@dvt/engine/src/index.ts`, `packages/@dvt/engine/src/core/WorkflowEngine.ts`, `packages/@dvt/adapter-temporal/src/TemporalAdapter.ts`, `packages/adapters-legacy/README.md`, `docs/REPO_STRUCTURE_SUMMARY.md`
- 2026-02-17 · iteration-3
  - Summary: Added deterministic DAG-layer scheduler slice for `#15`; recorded new debt TD-0006 for shared-contract alignment of `dependsOn`.
  - Evidence: `packages/@dvt/adapter-temporal/src/workflows/RunPlanWorkflow.ts`, `packages/@dvt/adapter-temporal/src/engine-types.ts`, `packages/@dvt/engine/src/contracts/executionPlan.ts`
- 2026-02-17 · iteration-4
  - Summary: Promoted `dependsOn` to shared engine execution plan contract and aligned mock adapter/test coverage; closed TD-0006.
  - Evidence: `packages/@dvt/engine/src/contracts/executionPlan.ts`, `packages/@dvt/engine/src/adapters/mock/MockAdapter.ts`, `packages/@dvt/engine/test/contracts/engine.test.ts`
- 2026-02-17 · iteration-5
  - Summary: Converted vague debt statements into explicit tracked entries TD-0007 (lint backlog routes) and TD-0008 (docs/path queue by file).
  - Evidence: `docs/status/IMPLEMENTATION_SUMMARY.md`, `docs/guides/TECHNICAL_DEBT_REGISTER.md`
- 2026-02-17 · iteration-6
  - Summary: Completed issue `#15` Option A slices (retry/error + E2E golden path); no additional technical debt introduced in this iteration.
  - Evidence: `packages/@dvt/adapter-temporal/src/workflows/RunPlanWorkflow.ts`, `packages/@dvt/adapter-temporal/src/activities/stepActivities.ts`, `packages/@dvt/adapter-temporal/test/integration.time-skipping.test.ts`
- 2026-02-18 · iteration-7
  - Summary: Captured post-closure hardening backlog for Temporal runtime: determinism linting CI guardrails and long-activity heartbeat policy.
  - Evidence: `docs/decisions/ADR-0007-temporal-retry-policy-mvp.md`, `docs/guides/TECHNICAL_DEBT_REGISTER.md`, `docs/status/IMPLEMENTATION_SUMMARY.md`
- 2026-02-19 · iteration-8
  - Summary: Implemented contracts-only slice for issue `#220` (`CanvasState` schema v1), no new technical debt.
  - Evidence: `docs/architecture/engine/contracts/schemas/canvas-state.schema.json`, `docs/architecture/engine/contracts/README.md`, `.gh-comments/issue-220-prebrief.md`
- 2026-02-19 · iteration-9
  - Summary: Implemented contracts-only slice for issue `#221` (`ProvenanceEvent` schema v1), no new technical debt.
  - Evidence: `docs/architecture/engine/contracts/schemas/provenance-event.schema.json`, `docs/architecture/engine/contracts/README.md`, `.gh-comments/issue-221-prebrief.md`
- 2026-02-20 · iteration-10
  - Summary: Added post-checkpoint debt entries for typed error consistency, `src`/`dist` artifact synchronization, and engine test fixture typing hardening.
  - Evidence: `docs/planning/IMPLEMENTATION-PLAN-ARCH-REVIEW.md`, `ROADMAP.md`, `docs/guides/TECHNICAL_DEBT_REGISTER.md`
- 2026-02-20 · iteration-11
  - Summary: Confirmed microcommit strategy will omit `dist/` artifacts from commits; TD-0012 remains open and explicitly tracked until release rebuild/publish parity workflow is executed.
  - Evidence: `docs/guides/TECHNICAL_DEBT_REGISTER.md`, `.gitignore`
